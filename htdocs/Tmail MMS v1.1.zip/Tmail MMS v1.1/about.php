<table width="100%" border="0" align="center" cellpadding="0" cellspacing="1">
  <tr>
    <td width="93%" class="h3">ABOUT</td>
  </tr>
  <tr>
    <td class="small"><em>Some more things about the script .</em></td>
  </tr>
</table>
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="10">
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
</table>
