<?php if(!isset($_SESSION['admin'])) {echo ' Hacking Attempted '; return; } ?><!------- Start of HTML Code ------->
<table width="700" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td><div align="center">
  <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td width="30"><div align="center"><img src="admin/images/help.gif" width="20" height="20"></div></td>
      <td class="h3"> <table width="100%" border="0" cellpadding="0" cellspacing="0">
          <tr>
            <td class="h3">Help</td>
            <td valign="bottom"><div align="right" class="f8">Some help
                about the script .</div></td>
          </tr>
        </table></td>
    </tr>
    <tr>
      <td width="30"><img src="images/interface/spacer.gif" width="1" height="10"></td>
      <td></td>
    </tr>
    <tr bgcolor="#0066CC">
      <td colspan="2"><img src="images/interface/spacer.gif" width="1" height="1"></td>
    </tr>
  </table>
  <br>
  <br>
  <div align="center">
    <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td width="10" height="10"><img src="admin/images/interface/top_left_corner.png" width="10" height="10" /></td>
        <td background="admin/images/interface/top_line.png"></td>
        <td width="10" height="10"><img src="admin/images/interface/top_right_corner.png" width="10" height="10" /></td>
      </tr>
      <tr>
        <td background="admin/images/interface/left_line.png"></td>
        <td bgcolor="#FFFFFF"><div align="right">
          <table width="750" border="0" align="center" cellpadding="0" cellspacing="2">
            <tr>
              <td><table width="100%" border="0" cellpadding="5" cellspacing="0" bgcolor="#FFFFFF">
                  <tr>
                    <td>
                      <table width="100%" border="0" cellpadding="2" cellspacing="0" bgcolor="#000000">
                        <tr>
                          <td><font color="#FFFFFF">Tmail MMS ( ver 1.0) HELP </font></td>
                        </tr>
                      </table>
                      <table width="100%" border="0" cellspacing="0" cellpadding="0">
                        <tr>
                          <td><div align="right"></div></td>
                        </tr>
                      </table>
                      <br>
                      <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="f7f7f7">
                        <tr>
                          <td width="20%"><strong>Welcome </strong></td>
                          <td width="80%"><em><font color="#666666">Table of content .</font></em></td>
                        </tr>
                        <tr bgcolor="#FFFFFF">
                          <td>&nbsp;</td>
                          <td><p><a href="#about">&#8226; About </a><br>
                                  <a href="#about">&#8226; </a><a href="#disclamer">Disclaimer</a><br>
                                  <a href="#about">&#8226; </a><a href="#installation">Installation </a><br>
                                  <a href="#about">&#8226; </a><a href="#usage">Usage</a><br>
                                  <a href="#about">&#8226; </a><a href="#support">Support </a><br>
                                  <a href="#about">&#8226; </a><a href="#history">History</a><br>
                          </p></td>
                        </tr>
                      </table>
                      <br>
                      <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="f7f7f7">
                        <tr>
                          <td width="20%"><strong><a name="about"></a>About </strong></td>
                          <td width="80%"><em><font color="#666666">About the script </font></em></td>
                        </tr>
                        <tr bgcolor="#FFFFFF">
                          <td>&nbsp;</td>
                          <td><p><br>
                    Toll专业邮件订阅与时事通讯管理系统可以协助你管理中小型网站的用户,使用它可以使你更加快捷的与客户联系沟通. 它不需要用户懂得任何的 HTML 或 PHP . 它努力实现简单但强大... </p>
                            <p> 它的诞生是因为很多的管理者（这些管理者,有一定的管理才能,但是并不能自己设计,或是不太熟悉mail的相关设计.）需要一个这样的软件来管理自己的客户,利用此软件来及时地给客户传递信息,以免延误一些重要的事情,比如:你发布的某软件存在漏洞,这个时候就需要第一时间把相关信息传达给用户. 此软件遵循互联网的相关约定与标准,客户自己选择是否成为接受邮件的对象,还可以选择索要资料/信息的种类,根据客户的要求,我们把这些可以分组以区别管理!这样一来,客户可以避免接受垃圾信息,而管理者又有效的发送了信息! </p>
                            <p>这个软件更是为了管理者设计.因为我们的管理后台功能强大,操作简单.我们软件会在收集了用户的建议之后进行不定期的更新 . 请大家注意www.cms8.com的公告, </p>
                            <p><br>
                              </p></td>
                        </tr>
                      </table>
                      <br>
                      <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr bgcolor="f7f7f7">
                          <td width="20%"><strong><a name="disclamer"></a>Disclaimer</strong></td>
                          <td width="80%"><font color="#666666"><em>Copyrights and warnings . </em></font></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td><br>
                  此项目开源,但请你在修改过程中,保留本站www.cms8.com的链接<br>
                                    <br>
                                    <font color="#FF3300">* USE IT AT YOUR OWN RISK *</font></td>
                        </tr>
                      </table>
                      <br>
                      <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr bgcolor="f7f7f7">
                          <td width="20%"><strong><a name="installation"></a>Installation </strong></td>
                          <td width="80%"><em><font color="#666666">How to install . </font></em></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td> <p>http://www.cms8.com/mail/maillist/help/html/quickstart.htm#steps</p>
                            <p>请到以上网址查看详情</p></td>
                        </tr>
                      </table>
                      <br>
                      <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr bgcolor="f7f7f7">
                          <td width="20%"><strong><a name="usage"></a>Usage </strong></td>
                          <td width="80%"><font color="#666666"><em>How to use .</em></font></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td>
                            <p>http://www.cms8.com/mail/maillist/help/html/quickstart.htm</p>
                            <p>请到以上网址查看详情</p></td>
                        </tr>
                      </table>
                      <br>
                      <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr bgcolor="f7f7f7">
                          <td width="20%"><strong><a name="support"></a>Support </strong></td>
                          <td width="80%"><em><font color="#666666">If you have a problem .</font></em></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td>
                            <p>仅仅为那些遵循了 The free(GPL) nature of the program的人提供技术支持 (保留版权的用户). <br>
资助本程序的人将获取特别的技术支持. </p>
                            <p>请访问www.cms8.com寻求技术支持. </p></td>
                        </tr>
                      </table>
                      <br>
                      <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
                        <tr bgcolor="f7f7f7">
                          <td width="20%"><strong><a name="history"></a>History </strong></td>
                          <td width="80%"><em><font color="#666666">Previous versions and bug fixes .</font></em></td>
                        </tr>
                        <tr>
                          <td>&nbsp;</td>
                          <td><p><a name="updates"></a>历史 </p>
                              <p>本人首次发布此程序,不存在历史版本. </p>
                              <p>此程序最初来源于国外,一个印第安人于2003年12月写的程序 . </p>
                              <p>此程序我已经使用了2年有余. </p>
                              <p>好东西,大家一起分享,所以近期内,本人Toll在原版本的基础上汉化并增加了部分新的功能,优化部分代码. </p>
                              <p>因本人汉化并且作了较大幅度的修改,因此没有保留其原版权,但会在显著部位注明其标记. <br>
                              </p>
                              <br>
                          </td>
                        </tr>
                      </table>
                      <p>&nbsp;</p></td>
                  </tr>
              </table></td>
            </tr>
          </table>
            </div></td>
        <td background="admin/images/interface/right_line.png"></td>
      </tr>
      <tr>
        <td width="10" height="10" background="admin/images/interface/bottom_left_corner.png"></td>
        <td background="admin/images/interface/bottom_line.png"></td>
        <td width="10" height="10" background="admin/images/interface/bottom_right_corner.png"></td>
      </tr>
    </table></td></tr>
    </table>
    <br>
  </div>
</div>