<?php
$t_name="Blue";
$t_author="myfreetemplates.com";
$t_desc="business template";
$t_home="http://www.cms8.com";
?>