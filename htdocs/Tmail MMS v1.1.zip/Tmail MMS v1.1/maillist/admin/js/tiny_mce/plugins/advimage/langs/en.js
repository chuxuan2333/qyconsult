// UK lang variables

tinyMCELang['lang_insert_image_alt2'] = 'Image title';
tinyMCELang['lang_insert_image_onmousemove'] = 'Alternative image'
tinyMCELang['lang_insert_image_mouseover'] = 'for mouse over';
tinyMCELang['lang_insert_image_mouseout'] = 'for mouse out';
