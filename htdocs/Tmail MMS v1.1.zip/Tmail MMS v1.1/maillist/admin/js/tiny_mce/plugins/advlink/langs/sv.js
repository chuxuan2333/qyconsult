// SE lang variables

tinyMCELang['lang_insert_link_target_same'] = '&Ouml;ppna i samma f&ouml;nster / ram';
tinyMCELang['lang_insert_link_target_parent'] = '&Ouml;ppna i underliggande f&ouml;nster / ram';
tinyMCELang['lang_insert_link_target_top'] = '&Ouml;ppna i toppramen (ers&auml;tter alla ramar)';
tinyMCELang['lang_insert_link_target_blank'] = '&Ouml;ppna i ett nytt f&ouml;nster';
tinyMCELang['lang_insert_link_target_named'] = '&Ouml;ppna i ett specifikt f&ouml;nster';
tinyMCELang['lang_insert_link_popup'] = 'JS-Popup';
tinyMCELang['lang_insert_link_popup_url'] = 'Popup URL';
tinyMCELang['lang_insert_link_popup_name'] = 'F&ouml;nstrets namn';
tinyMCELang['lang_insert_link_popup_return'] = 'S&auml;tt in \'return false\'';
tinyMCELang['lang_insert_link_popup_scrollbars'] = 'Visa scrollbars';
tinyMCELang['lang_insert_link_popup_statusbar'] = 'Visa statusbar';
tinyMCELang['lang_insert_link_popup_toolbar'] = 'Visa toolbars';
tinyMCELang['lang_insert_link_popup_menubar'] = 'Visa menubar';
tinyMCELang['lang_insert_link_popup_location'] = 'Visa locationbar';
tinyMCELang['lang_insert_link_popup_resizable'] = 'G&ouml;r f&ouml;nstret skalbart';
tinyMCELang['lang_insert_link_popup_size'] = 'Storlek';
tinyMCELang['lang_insert_link_popup_position'] = 'Position (X/Y)';
tinyMCELang['lang_insert_link_popup_missingtarget'] = 'Var god skriv ett namn f�r f�nstret eller v�lj ett annat val.';
