<?php
//this is the config file
include("../../../../../globals.php");
//path where the images are to be shown from
// your absolute path
$im_show_path=$absolute_path.'uploads/';
// you webpath
$im_webpath=$website.$main_dir."uploads/";
?>