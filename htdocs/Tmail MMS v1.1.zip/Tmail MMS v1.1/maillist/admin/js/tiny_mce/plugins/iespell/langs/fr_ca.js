// CAN_FR lang variables

tinyMCELang['lang_iespell_desc'] = 'Executer le v�rificateur d\'orthographe';
tinyMCELang['lang_iespell_download'] = "ieSpell n\'a pas �t� trouv�. Cliquez sur OK pour aller au site de t�l�chargement.";
