/* Import plugin specific language pack */
tinyMCE.importPluginLanguagePack('imanager', 'en,de,sv,zh_cn,cs,fa,fr_ca,fr');
