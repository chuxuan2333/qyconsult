// French lang variables by Laurent Dran

tinyMCELang['lang_insert_advhr_desc']    = 'Ins&eacute;rer / &eacute;diter une R&#269;gle Horizontale'
tinyMCELang['lang_insert_advhr_width']   = 'Largeur';
tinyMCELang['lang_insert_advhr_size']    = 'Hauteur';
tinyMCELang['lang_insert_advhr_noshade'] = 'Sans ombre';
