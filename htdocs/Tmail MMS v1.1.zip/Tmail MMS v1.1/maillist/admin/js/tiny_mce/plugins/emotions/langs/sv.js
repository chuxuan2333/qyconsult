// SE lang variables

tinyMCELang['lang_insert_emotions_title'] = 'Klistra in k�nsla';
tinyMCELang['lang_emotions_desc'] = 'K�nslor';
