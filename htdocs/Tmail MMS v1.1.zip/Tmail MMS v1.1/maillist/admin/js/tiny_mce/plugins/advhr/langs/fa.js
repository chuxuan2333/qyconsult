﻿// IR lang variables
// Persian (Farsi) language pack (for IRAN)
// By: Morteza Zafari
// Lost@LostLord.com
// http://www.LostLord.com

tinyMCELang['lang_dir'] = 'rtl';
tinyMCELang['lang_insert_advhr_desc']    = 'درج و ویرایش خط افقی'
tinyMCELang['lang_insert_advhr_width']   = 'عرض';
tinyMCELang['lang_insert_advhr_size']    = 'ارتفاع';
tinyMCELang['lang_insert_advhr_noshade'] = 'بدون سایه';
