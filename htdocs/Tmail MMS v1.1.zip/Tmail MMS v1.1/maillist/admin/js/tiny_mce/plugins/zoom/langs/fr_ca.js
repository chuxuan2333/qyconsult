// CA_FR lang variables

tinyMCELang['lang_zoom_prefix'] = 'Zoom';
