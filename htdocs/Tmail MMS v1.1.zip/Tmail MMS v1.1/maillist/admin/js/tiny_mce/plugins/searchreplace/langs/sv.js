// SE lang variables

tinyMCELang['lang_searchreplace_search_desc'] = 'S�k';
tinyMCELang['lang_searchreplace_searchnext_desc'] = 'S�k igen';
tinyMCELang['lang_searchreplace_replace_desc'] = 'S�k/Ers�tt';
tinyMCELang['lang_searchreplace_notfound'] = 'S�kningen �r slutf�rd. S�kstr�ngen kunde inte hittas.';
tinyMCELang['lang_searchreplace_search_title'] = 'S�k';
tinyMCELang['lang_searchreplace_replace_title'] = 'S�k/Ers�tt';
tinyMCELang['lang_searchreplace_allreplaced'] = 'Alla tr�ffar p� s�kstr�ngen ersattes';
tinyMCELang['lang_searchreplace_findwhat'] = 'S�k p�';
tinyMCELang['lang_searchreplace_replacewith'] = 'Ers�tt med';
tinyMCELang['lang_searchreplace_direction'] = 'S�kriktning';
tinyMCELang['lang_searchreplace_up'] = 'Upp�t';
tinyMCELang['lang_searchreplace_down'] = 'Ner�t';
tinyMCELang['lang_searchreplace_case'] = 'Matcha gemener/VERSALER';
tinyMCELang['lang_searchreplace_findnext'] = 'S�k&nbsp;n�sta';
tinyMCELang['lang_searchreplace_replace'] = 'Ers�tt';
tinyMCELang['lang_searchreplace_replaceall'] = 'Ers�tt&nbsp;alla';
tinyMCELang['lang_searchreplace_cancel'] = 'Avbryt';
