﻿// PL lang variables

tinyMCELang['lang_insert_emotions_title'] = 'Wstaw emtoiconę';
tinyMCELang['lang_emotions_desc'] = 'Emtoicony';