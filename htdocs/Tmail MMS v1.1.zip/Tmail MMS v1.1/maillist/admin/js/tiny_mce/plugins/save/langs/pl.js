﻿// PL lang variables


tinyMCELang['lang_save_desc'] = 'Zachowaj'; 