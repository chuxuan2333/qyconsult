// CAN_FR lang variables

tinyMCELang['lang_insertdate_desc'] = 'Ins�rer la date';
tinyMCELang['lang_inserttime_desc'] = 'Ins�rer l\'heure';
tinyMCELang['lang_inserttime_months_long'] = new Array("Janvier", "F�vrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Ao�t", "Septembre", "Octobre", "Novembre", "D�cembre");
tinyMCELang['lang_inserttime_months_short'] = new Array("Jan", "Fev", "Mar", "Avr", "Mai", "Juin", "Juil", "Aout", "Sep", "Oct", "Nov", "Dec");
tinyMCELang['lang_inserttime_day_long'] = new Array("Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche");
tinyMCELang['lang_inserttime_day_short'] = new Array("Lun", "Mar", "Mer", "Jeu", "Thu", "Ven", "Sam", "Dim");
