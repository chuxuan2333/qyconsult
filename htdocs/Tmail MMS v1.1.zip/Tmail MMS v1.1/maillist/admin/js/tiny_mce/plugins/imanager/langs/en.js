// UK lang variables

tinyMCELang['lang_imanager_desc']      = 'Insert or upload image';
