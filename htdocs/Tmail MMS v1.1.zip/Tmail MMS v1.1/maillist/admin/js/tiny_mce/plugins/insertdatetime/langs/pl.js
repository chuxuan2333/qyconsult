﻿// PL lang variables


tinyMCELang['lang_insertdate_desc'] = 'Wstaw aktualną datę';
tinyMCELang['lang_inserttime_desc'] = 'Wstaw aktualny czas';
tinyMCELang['lang_inserttime_months_long'] = new Array("Styczeń", "Luty", "Marzec", "Kwiecień", "Maj", "Czerwiec", "Lipiec", "Sierpień", "Wrzesień", "Październik", "Listopad", "Grudzień");
tinyMCELang['lang_inserttime_months_short'] = new Array("Stcz", "Lut", "Mar", "Kwi", "Maj", "Czer", "Lip", "Sier", "Wrze", "Paź", "List", "Grudz");
tinyMCELang['lang_inserttime_day_long'] = new Array("Niedziela", "Poniedziałek", "Wtorek", "Środa", "Czwartek", "Piątek", "Sobota", "Niedziela");
tinyMCELang['lang_inserttime_day_short'] = new Array("Nie", "Pon", "Wto", "Śro", "Czw", "Pia", "Sob", "Nie");