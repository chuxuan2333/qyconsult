<?php
/* These are not meant to be changed*/
$mailfile="email.txt";
$groupfile="group.txt";
$verifyfile="vemail.txt";
?>