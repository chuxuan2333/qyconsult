<font color="#000000" size="2">
<?php
//                  $view_type="main";
//                  $main_category="fad58de7366495db4650cfefac2fcd61";
                  include("mail.php")
                  ?>
</font>