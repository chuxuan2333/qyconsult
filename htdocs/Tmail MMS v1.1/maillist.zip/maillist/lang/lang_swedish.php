<?php

$lang_charset= "iso-8859-1";
/*headder Bar */
$lang_head_settings="Inst�llningar";
$lang_send_out_mail="Skicka e-post";
$lang_edit_mailing_groups="Grupper";
$lang_edit_mailing_list="E-postlista";
$lang_about="Om";
$lang_help="Hj�lp";
$lang_history="Historia";
$lang_logout="Logga ut";

/*logging setings */
$lang_login_manage="Redigera e-postlista l�tt";
$lang_login_username="Anv�ndarnamn";
$lang_login_passwords="L�senord";

/*main setings */
$lang_tail_total="Totalt antal prenumeranter:";
$lang_main_updated="Huvudinst�llningar �r �ndrade";
$lang_main_settings="Huvudinst�llningar ";
$lang_main_global="�ndra globala inst�llningar";
$lang_main_vote="R�sta";
$lang_main_diagnostics="Felrapport";
$lang_main_script="Script";
$lang_main_database="Databas";
$lang_main_email="E-post";
$lang_main_security="S�kerhet";
$lang_main_server="E-post Server";
$lang_main_script_about="Dessa inst�llningar m�ste g�ras f�r att skriptet ska fungera som det ska. L�s Hj�lpen om du har problem.";
$lang_main_website="Websajt:";
$lang_main_website_help="Adressen till sajten inklusive rot-s�kv�gen:";
$lang_main_relative="Relativ s�kv�g:";
$lang_main_relative_help="Denna s�kv�g talar om var mail-listans mapp �r.";
$lang_main_absolute_path="Absolut s�kv�g :";
$lang_main_absolute_path_help="Detta �r filsystemets s�kv�g ";
$lang_main_string="Relativ str�ng:";
$lang_main_string_help="H�r skriver du in namnet p� filen d�r mail-listan �r inb�ddad, plus <B>?page=mail&</B> efter�t.";
$lang_main_rc4="Unik RC4 krypterings str�ng :";
$lang_main_encrypt="Till�t RC4 kryptering :";
$lang_main_encrypt_help="V�lj kryptering om du �nskar kryptering vald f�r dina text filer. ";
$lang_main_popup_help="Om du vill att registreringen ska ske med pop-upp-f�nster, och om du vill undvika den relativa str�ngen.";
$lang_main_popup="Aktivera pop-upp:";
$lang_main_rc4_help="Fyll h�r i en unik RC$ str�ng som kommer att anv�ndas f�r att kryptera dina text filer med.";
$lang_main_Language="V�lj spr�k:";
$lang_main_Language_help="V�lj spr�k f�r allt";
$lang_main_databaseset="Databas inst�llningar";
$lang_main_databasesetex="V�lj den databas du �nskar anv�nda. ";
$lang_main_mysql="Anv�nd MySQL";
$lang_main_mysql_help="Om du vill anv�nda MySQL eller textfil";
$lang_main_hostname="V�rdnamn:";
$lang_main_hostname_help="V�rdnamn f�r databasens server";
$lang_main_databaseuser="Databasens anv�ndarnamn:";
$lang_main_databaseuser_help="Ditt anv�ndarnamn f�r att logga in i databasen";
$lang_main_databasepass="Databasens l�senord:";
$lang_main_databasepass_help="Ditt l�senord f�r att logga in i databasen";
$lang_main_databasename="Databasens namn:";
$lang_main_databasename_help="Databasens namn, d�r tabellen finns";
$lang_main_emailex="H�r anger du hur dina e-postmeddelanden ska skickas, och du kan �ndra inst�llningarna f�r deras egenskaper. Ange �ven saker som huruvida av-prenumeration ska inkluderas eller inte.";
$lang_main_emailname="Skicka e-post i detta namn:";
$lang_main_emailname_help="Namnet p� den som skickar e-postmeddelandent!";
$lang_main_emailadress="Skicka e-post fr�n denna adress:";
$lang_main_emailadress_help="Avs�ndarens e-postadress!";
$lang_main_thankstitle="Tack titel p� e-postmeddelandet:";
$lang_main_thankstitle_help="Titel p� dina tack meddelanden";
$lang_main_thanksmessage="Tack meddelande:";
$lang_main_thanksmessage_help="Detta meddelande kommer att inkluderas i e-postmeddelandent n�r prenumeranten registrerat.";
$lang_main_unsubscribe="Av prenumerations meddelande:";
$lang_main_unsubscribe_help="Av prenumerations meddelande!";
$lang_main_verify="Bekr�fta e-post prenumerationen:";
$lang_main_verify_help="Detta meddelande kommer att inkluderas i e-postmeddelandent n�r prenumeranten ska bekr�fta prenumerationen";
$lang_main_includeunsubscribe="Inkludera l�nk till avprenumerering:";
$lang_main_includeunsubscribe_help="E-postmeddelanden kommer att inneh�lla en l�nk f�r avprenumeration.";
$lang_yes="Ja";
$lang_no="Nej";
$lang_main_thankmail="Tack e-post:";
$lang_main_thankmail_help="Skicka tack f�r prenumeration.";
$lang_main_verification="E-post bekr�ftelse:";
$lang_main_verification_help="Prenumeranten blir registrerad f�rst efter att bekr�ftelse skett i det e-postmeddelande som skickas";
 $lang_main_htmlarea="Enable HTML area in sendmail form";
 $lang_main_htmlarea_help="This will show an HTML area in the send form.";
$lang_main_images="Skicka med bilder tillsammans med dina e-post meddelande. :";
$lang_main_images_help="Om vald kommer bilderna ocks� att skickas , annars skapas l�nkar till bilderna i det skickade e-postmeddelandet.";
$lang_main_securityex="H�r anger du namn och l�senord f�r att kunna administrera e-postlistan.";
$lang_main_username="Anv�ndarnamn:";
$lang_main_username_help="Detta anv�ndarnamn �r f�r administrat�rens inloggning";
$lang_main_password="L�senord:";
$lang_main_password_help="Detta l�senord �r f�r administrat�rens inloggning";
$lang_main_mailserver="E-post server";
$lang_main_mailserverex="H�r anger du metoden f�r att e-post ska skickas. Oftast fungerar PHP-metoden v�l.";
$lang_main_selectmethod="V�lj metod f�r att skicka e-post:";
$lang_main_selectmethod_help="V�lj metod f�r att skicka e-post";
$lang_main_sendmail="S�kv�g f�r Sendmail";
$lang_main_sendmail_help="Skriv in s�kv�gen f�r Sendmail h�r";
$lang_main_smtpserver="SMTP-serverns namn";
$lang_main_smtpserver_help="Detta �r adressen till SMTP-servern";
$lang_main_smtpauthentication="Autentisering";
$lang_main_smtpauthentication_help="Om din SMTP-server kr�ver autentisering, fyll i anv�ndarnamn och l�senord";
$lang_main_smtpuser="Anv�ndarnamn";
$lang_main_smtpuser_help="Anv�ndar namn";
$lang_main_smtppass="L�senord";
$lang_main_update="Uppdatera";

/*sendmail */
$lang_sendmail_suberror="Fyll i �mne";
$lang_sendmail_fillerror="Fyll i HTML- eller Text-mail";
$lang_sendmail_send="Skicka e-post";
$lang_sendmail_sendex="Skicka e-post - Du kan skicka olika typer av e-post h�rifr�n";
$lang_sendmail_sendselect="Ange vilken typ av e-post du vill skicka.";
$lang_sendmail_from="E-post fr�n";
$lang_sendmail_subject="�mne";
$lang_sendmail_text="Text-version";
$lang_sendmail_textversion="<strong>Text-version </strong>av e-post: <br> <font color=#999999>H�r kan du skriva in text-versionen av e-brevet </font>";
$lang_sendmail_htmlversion="<strong>HTML-version</strong> av e-post: <br> <font color=#999999>H�r kan du klistra in eller skriva in html-versionen av e-brevet</font>";
$lang_sendmail_textversion_view="<strong>Text Version </strong>av E-post : <br> ";
$lang_sendmail_htmlversion_view="<strong>HTML Version</strong> av E-post : <br> ";
$lang_sendmail_selecttemplate="V�lj mall";
$lang_sendmail_usetemplate="Anv�nd mallar";
$lang_sendmail_selecttemplate="V�lj mall";
$lang_sendmail_selectdraft="V�lj ett utkast";
$lang_sendmail_errortemplate="Fel: Kunde inte n� mappen f�r mallarna!";
$lang_sendmail_errordrafts="Fel : Kunde ej �ppna mappen med utkast! !!";
$lang_sendmail_helptemplate="L�s i Hj�lpen hur man redigerar mallallarna.";
$lang_sendmail_attachment="Bilaga";
$lang_sendmail_sendbutton="Skicka";
$lang_sendmail_nextbutton="N�sta";
$lang_sendmail_backbutton="Tillbaka";
$lang_sendmail_stage1="Steg 1";
$lang_sendmail_stage2="Steg 2";
$lang_sendmail_stage3="Steg 3";
$lang_sendmail_to="Skicka e-post till ";
$lang_sendmail_to_help="V�nligen v�lj h�r till vem du �nskar skicka e-post. ";
$lang_sendmail_emailID="E-post ID";
$lang_sendmail_emailID_help="V�nligen fyll i den e-postadress till vilken du �nskat skicka e-post.";
$lang_sendmail_group="Skicka e-post till en grupp.";
$lang_sendmail_group_help="V�nligen v�lj den grupp du �nskar skicka e-post till.";
$lang_sendmail_single_error="Du har inte fyllt i en e-post mottagares e-postadress.";
$lang_sendmail_group_error="Du har inte valt en grupp att skicka e-post till.";
$lang_sendmail_wysiwyg="Klicka H�r f�r att edititera med en rich text editerare";
$lang_sendmail_single="Till en e-postmottagare";
$lang_sendmail_group="Till en grupp";
$lang_sendmail_every="Till alla";

/*edit sending */
$lang_send_wait="V�nligen v�nta ... <br><br> Skickar E-post";
$lang_send_done="E-post skickad !!<br><br>";
$lang_send_mailing="TOLL E-postlista skickar E-post ...";

/*edit wysiwyg */
$lang_editwin_edit="Rich text editerare";
$lang_editwin_help="Editera HTML med en HTML editor h�r";

 /*edit maillist members */
$lang_edit_list="�ndra e-postlista";
$lang_edit_listex="H�r kan du l�gga till, s�ka och redigera e-postlistors mottagare. ";
$lang_edit_new="Ange nytt e-brev som ska l�ggas till";
$lang_edit_new_name="V�nligen fill i namnet p� det e-post meddelande som skall l�ggas till. ";
$lang_edit_nomailgroup="V�nligen v�lj en e-postlista grupp.";
$lang_edit_expression="Ange s�kningsuttryck";
$lang_edit_correct="Skriv in en korrekt e-postadress: ";
$lang_edit_correct_name="V�nligen fyll i ett namn: ";
$lang_edit_delete="Vill du ta bort detta? ";
$lang_edit_jump="---- V�lj mottagare ----";
$lang_edit_jump_group="---- V�lj grupp ----";
$lang_edit_import="Importera";
$lang_edit_export="Exportera";
$lang_edit_add="L�gg till prenumerant";
$lang_edit_search="S�k";
$lang_edit_refresh="Uppdatera";
$lang_edit_editdata="�ndra databasen";
$lang_edit_editdataex="V�nligen v�lj det du vill g�ra genom att klicka p� l�nkarna nedan till h�ger.";
$lang_edit_submitted="Skapad den";
$lang_edit_ip="ip-adress";
$lang_edit_ipedit="�ndra";
$lang_edit_ipdelete="Ta bort";
$lang_edit_select="<Br><br><center>...V�nligen v�lj den grupp du vill �ndra...</center><Br><br>";

/*edit maillist members */
$lang_editg_deleted="<br><br><center>Gruppen <strong>{group}</strong> har raderats! !!</center><br><br>";
$lang_editg_added="<br><br><center>Gruppen <strong>{group}</strong> har skapats!!!</center><br><br>";
$lang_editg_added_error="<br><br><center>Gruppen <strong>{group}</strong> finns redan! !!</center><br><br>";
$lang_editg_adit="<br><br><center>Gruppen <strong>{group}</strong> har �ndrats! !!</center><br><br>";
$lang_editg_list="�ndra e-postlista grupper";
$lang_editg_listex="H�rifr�n kan du l�gga till , s�ka och �ndra e-postlista grupper. ";
$lang_editg_new_name="Skriv namnet p� den nya grupp som skall l�ggas till";
$lang_editg_new="V�nligen fyll i ett unikt ID f�r gruppen";
$lang_editg_expression="V�nligen fyll i den grupp du �nskar s�ka i.";
$lang_editg_correct="V�nligen fyll i gruppens ID :";
$lang_editg_correct_name="V�nligen fyll i gruppens namn :";
$lang_editg_delete="Vill du radera gruppen :";
$lang_editg_jump="---- Snabb val ----";
$lang_editg_add="L�gg till grupp";
$lang_editg_search="S�k";
$lang_editg_refresh="Uppdatera";
$lang_editg_editdata="�ndra databasen";
$lang_editg_editdataex="V�nligen v�lj det du vill g�ra genom att klicka p� l�nkarna nedan till h�ger. ";
$lang_editg_ipedit="�ndra";
$lang_editg_ipdelete="Radera";
$lang_editg_subscribers="Prenumeranter";
$lang_editg_name="Gruppens namn ( ID )";

/*edit maillist history */
$lang_edith_title="E-post historia";
$lang_edith_titlex="En lista p� alla skickade e-post meddelande.";
$lang_edith_editdata="Tidigare skickade meddelanden";
$lang_edith_editdataex="V�lj det du �nskar g�ra med ett tidigare skickat e-post meddelande genom att v�lja en av l�nkarna till h�ger. ";
$lang_edith_date="Datum";
$lang_edith_edit="Skicka igen";
$lang_edith_to="Skicka till";
$lang_edith_delete="Radera";
$lang_edith_delete_history="Vill du ta bort det tidigare skickade meddelandet? : ";
$lang_edith_subject="�mne ";

 /*diagnostics */
$lang_diag_simple="Enkel diagnostik";
$lang_diag_simpleex="Denna sida kontrollerar om vissa filer har korrekta beh�righeter.";
$lang_diag_status="Status";
$lang_diag_checking="Kontrollerar / Fel";
$lang_diag_globals="Om det uppstod ett fel, s� �r filen inte skrivbar f�r www. �ndra filens beh�righet.";

$lang_diag_temp="Om det uppstod ett fel, s� �r \"temp\"-mappen inte skriv-bar. �ndra mappens beh�righet";

/*import */
$lang_import_adress="Importera e-postadresser.";
$lang_import_adressex="H�r kan du importera e-postadresser fr�n en text-fil.";
$lang_import_import="Textfil som ska importeras:";
$lang_import_import_help="V�lj textfil som ska importeras. E-postadresserna ska vara skrivna i filen rad f�r rad (separerade med radslut).";
$lang_import_next="N�sta";
$lang_import_group="Importera till grupp.";
$lang_import_group_help="Detta �r den grupp till vilken e-post kommer att importeras.";
$lang_import_close="St�ng";

/*mainnn inc files */
$lang_email_thanks="Tack f�r att du prenumererade!";
$lang_emailexist_error="Fel vid prenumeration!";
$lang_emailexist_adress="E-postadressen {email} finns redan! ";
$lang_emailexist_adress_error="E-postadressen {email} finns inte! ";
$lang_emailreg_verify="Nu har du f�tt e-post till {email}. I det hittar du en l�nk f�r att bekr�fta prenumerationen .";
$lang_emailreg_done="E-postadressen {email} registrerad.";
$lang_emailunreg_done="E-post adressen {email} �r nu borttagen fr�n databasen. ";
$lang_emailremove_removed="E-postadressen borttagen.";
$lang_removed_adress="E-postadressen {email} togs bort.";

/*editor */
$lang_htmledit_cancel="Avbryt";
$lang_htmledit_reset="�terst�ll";
$lang_htmledit_save="Spara";

/*Search */
$lang_search_email="Emails Searchs";
$lang_search_emailex="Here, you can make an avanced search in the Email list";
$lang_search_group="Search in this groups: ";
$lang_search_group_help="The Search will be made in this group";
$lang_search_text="Search Text";
$lang_search="Search";
$lang_search_text_help="In order to look for ex. hotmail.com, try *@hotmail.com, it is used <strong>*</strong> like jokers, if you want to search for ex. webmaster, look for webmaster@*";
$lang_search_allgroups="On all Groups";
$lang_search_text_filter="Total Found";

/* addons*/
$lang_total_group_entries="Total Group Entries:";
$lang_email_name="Email ( Name )";
$lang_send_email="Send a Email";
$lang_show_all_group="Show All Groups";
$lang_see_group="Show Group";

/* charset iso */
$lang_charsetiso[1]="8859-1 - western Europe (Latin-1)";
$lang_charsetiso[2]="8859-2 - Eastern Europe (Latin-2)";
$lang_charsetiso[3]="8859-3 - Southeast of Europe & more (Latin-3)";
$lang_charsetiso[4]="8859-4 - Scandinavian/Balkan (Latin-4)";
$lang_charsetiso[5]="8859-5 - Lat�n/Cyrillic";
$lang_charsetiso[6]="8859-6 - Lat�n/Arab";
$lang_charsetiso[7]="8859-7 - Lat�n/Greek";
$lang_charsetiso[8]="8859-8 - Lat�n/Hebrew";
$lang_charsetiso[9]="8859-9 - Modification Latin-1 Turkish (Latin-5)";
$lang_charsetiso[10]="8859-10 - Lappish/Norway/Eskimo (Latin-6)";
$lang_charsetiso[11]="8859-11 - Thailand";
$lang_charsetiso[12]="8859-12 - Celtic (Latin-7)";
$lang_charsetiso[13]="8859-13 - Baltic (Latin-7)";
$lang_charsetiso[14]="8859-14 - Celtic (Latin-8)";
$lang_charsetiso[15]="8859-15 - Western Europe (Latin-9)";
$lang_charsetiso[16]="8859-16 - South-Eastern European (Latin-10)";
$lang_charsetiso[25]="UTF-8 - Unicode";
$lang_charsetiso[26]="WIN1256 - - Arabic & Persian HTML";//win1256
$lang_charsetiso[27]="CP-866 - Russia";
$lang_charsetiso[28]="TIS-620 - Thailand";
$lang_charsetiso[29]="EUC - Japanese";
$lang_charsetiso[30]="SJIS - Japanese";
$lang_charsetiso[31]="EUC-KR - Korea";
$lang_charsetiso[32]="KOI8-R - Russia";
$lang_charsetiso[33]="GB2312 - Chinese Simplified";
$lang_charsetiso[34]="BIG5 - Chinese Traditional";
$lang_charsetiso[35]="windows-1251 - Bulgaria";

/* new translations*/
$lang_sendmail_everyone="You have chosen to send email to every one in the database";
$lang_main_charsetiso_help="The type of Charset-iso for you email list";
$lang_main_charset="Charset-Iso To Send";
$lang_main_priority_help="The priority of the sending email list";
$lang_priority_text="Priority";
$lang_priority_high="High";
$lang_priority_normal="Normal";
$lang_priority_low="Low";
$lang_sendmail_fromerror="You forgot to fill in Email From";
$lang_sendmail_templateName="Template name";
$lang_sendmail_TemplateAuthor="Template Author";
$lang_sendmail_templateDescription="Description";
$lang_sendmail_templateHomepage="Homepage";
$lang_sendmail_templateNone="None";
?>