<?php

$lang_charset= "iso-8859-2";
/*headder Bar */
$lang_head_settings="Nastavenia";
$lang_send_out_mail="Posla� e-mail";
$lang_edit_mailing_groups="Skupiny";
$lang_edit_mailing_list="Adresy";
$lang_about="O programe";
$lang_help="Pomoc";
$lang_history="Hist�ria";
$lang_logout="Odhl�si�";

/*logging setings */
$lang_login_manage="Jednoduch� mana�ovanie adries";
$lang_login_username="Meno";
$lang_login_passwords="Heslo";

/*main setings */
$lang_tail_total="Celkom up�san�ch:";
$lang_main_updated="Aktualizovan� hlavn� konfigura�n� s�bor";
$lang_main_settings="Z�kladn� panel nastaven�";
$lang_main_global="Zmeni� celkov� nastavenia";
$lang_main_vote="Hlasuj";
$lang_main_diagnostics="Chybov� spr�va";
$lang_main_script="Nastavenie skriptu";
$lang_main_database="Datab�za";
$lang_main_email="Nastavenie E-mailu";
$lang_main_security="Bezpe�nostn� nastavenia";
$lang_main_server="Po�tov� server";
$lang_main_script_about="Jednotliv� nastavenia, ktor� s� potrebn� pre spr�vne fungovanie skriptu. Ak m�te nejak� probl�my, pre�itajte si pros�m Pomoc. ";
$lang_main_website="Web str�nka";
$lang_main_website_help="Meno web str�nky with hlavnou cestou (root path)!";
$lang_main_relative="�iasto�n� cesta (relative path) :";
$lang_main_relative_help="Cesta ku miestu ulo�enia adres�ra Mailing list-u (Zoznamu adries)!";
$lang_main_absolute_path="�pln� cesta (Absolute path) :";
$lang_main_absolute_path_help="Cesta syst�mu s�borov (file system path) ";
$lang_main_string="�iasto�n� re�azec (Relative String) :";
$lang_main_string_help="Meno s�boru kde ste ulo&frac34;ili zoznam adries s <B>?page=mail&</B> za n�m!";
$lang_main_rc4="Jedin� RC4 encrypt string :";
$lang_main_encrypt="Umo�ni� RC4 encryption :";
$lang_main_encrypt_help="Vyberte ak chcete ma� enkrypciu umo�nen� vo va�ich s�boroch";
$lang_main_popup_help="Ak chcete vykon�va� registr�cie vo vyskakuj�cich okn�ch.  Tie� ak sa chcete vyhn�� �iasto�n�mu re�azcu.";
$lang_main_popup="Umo�ni� popup :";
$lang_main_rc4_help="Enter here a uniqe RC$ sting which will be used to encrypt records in your text file.";
$lang_main_Language="Vyber jazyk :";
$lang_main_Language_help="Vyber jazyk";
$lang_main_databaseset="Nastavenia datab�zy";
$lang_main_databasesetex="Vyberte �i chcete datab�zu v textovom s�bore alebo tab�zu. Ak chcete prenies� textov� s�bor do MySQL, importujte text pomocou PHPAdmin.";
$lang_main_mysql="Pou�i MySQL";
$lang_main_mysql_help="Chcete pou�i� MySQL alebo textov� s�bor";
$lang_main_hostname="Hos�ovacie meno (Hostname) :";
$lang_main_hostname_help="Hos�ovacie meno (Hostname) serverovej datab�zy";
$lang_main_databaseuser="U��vate�sk� meno datab�zy :";
$lang_main_databaseuser_help="Va�e u��vate�sk� meno pre prihl�seni sa do datab�zy";
$lang_main_databasepass="Heslo datab�zy :";
$lang_main_databasepass_help="Va�e heslo pre prihl�senie sa do datab�zy";
$lang_main_databasename="Meno datab�zy:";
$lang_main_databasename_help="Meno datab�zy v ktorej s� tabu�ky";
$lang_main_emailex="�pecifik�cia posielania e-mailov a jednotliv� vlastnosti v�ho e-mailu. Tie� upresnite dal�ie vlastnosti ako napr. umo�nenie linky na odhl�senie e-mailu.";
$lang_main_emailname="Posla� e-mail pomocou v�ho mena :";
$lang_main_emailname_help="Meno odosielate�a zoznamu adries!";
$lang_main_emailadress="Posla� e-mail z adresy :";
$lang_main_emailadress_help="E-mail odosielate�a!";
$lang_main_thankstitle="Nadpis �akovn�ho e-mailu :";
$lang_main_thankstitle_help="Hlavi�ka e-mailu pre �akovn� odkazy";
$lang_main_thanksmessage="�akovn� e-mail :";
$lang_main_thanksmessage_help="Odkaz, ktor� bude zahrnut� ked sa pou��vate� zaregistruje na va�ej str�nke po �spe�nej registr�cii!";
$lang_main_unsubscribe="Odhlasovac� odkaz :";
$lang_main_unsubscribe_help="Odhlasovac� odkaz! ";
$lang_main_verify="Overi� prihl�seni e-mailu :";
$lang_main_verify_help="Odkaz, ktor� bude zahrnut� pri overovan� prihl�senia e-mailu!";
$lang_main_includeunsubscribe="Zahrn�� odhlasovaniu linku :";
$lang_main_includeunsubscribe_help="Ohlasovacia linka bude na konci e-mailu.";
$lang_yes="�no";
$lang_no="Nie";
$lang_main_thankmail="�akovn� e-mail :";
$lang_main_thankmail_help="Posla� �akovn� e-mail pri registr�cii. ";
$lang_main_verification="Overenie e-mailu :";
$lang_main_verification_help="E-mail prihlasovate�a bude pridan� a� po jeho overen� pomocou e-mailu, ktor� sa mu po�le.";
$lang_main_htmlarea="Umo�ni� HTML pole vo forme sendmail";
$lang_main_htmlarea_help="Uk�e HTML pole vo zasielacej forme.";
$lang_main_images="Obr�zky vsaden� do e-mailu :";
$lang_main_images_help="Ak umo�nen�, obr�zky sa tie� odo�l�. V opa�nom pr�pade bud� sp�tne prepojen�.";
$lang_main_securityex="Tu m��ete zada� va�e meno u��vate�sk� meno a heslo na pripojenie do administr�torsk�ho panelu.";
$lang_main_username="U��vate�sk� meno :";
$lang_main_username_help="U��vate�sk� meno pre administr�torsk� prihl�senie";
$lang_main_password="Heslo :";
$lang_main_password_help="Heslo pre administr�torsk� prihl�senie";
$lang_main_mailserver="Po�tov� server";
$lang_main_mailserverex="�pecifik�cia typu pre zasielanie e-mailov.  Pre v��inu pr�padou sta�� PHP mail funkcia.";
$lang_main_selectmethod="Vyberte met�du zasielania e-mailov :";
$lang_main_selectmethod_help="Vyberte met�du pre zasielanie e-mailov";
$lang_main_sendmail="Cesta pre Sendmail(Sendmail Path)";
$lang_main_sendmail_help="Vypl�te cestu pre sendmail";
$lang_main_smtpserver="SMTP Meno servera";
$lang_main_smtpserver_help="Adresa SMTP servera";
$lang_main_smtpauthentication="Verifik�cia";
$lang_main_smtpauthentication_help="Ak v� SMTP server vy�aduje Verifik�ciu, vypl�te u��vate�sk� meno a heslo";
$lang_main_smtpuser="U��vate�sk� meno";
$lang_main_smtpuser_help="U��vate�sk� meno";
$lang_main_smtppass="Heslo";
$lang_main_update="Aktualizova�";

/*sendmail */
$lang_sendmail_suberror="Vypl�te predmet";
$lang_sendmail_fillerror="Vypl�te Html alebo Textov� e-mail";
$lang_sendmail_send="Posla� E-mail";
$lang_sendmail_sendex="Posla� E-mail.";
$lang_sendmail_sendselect="Vyberte typ e-mailu, ktor� chcete odosla� a
vypl�te pr�slu�n� okno.";
$lang_sendmail_from="E-mail od";
$lang_sendmail_subject="Predmet";
$lang_sendmail_text="Textov� verzia";
$lang_sendmail_textversion="<strong>Textov� verzia </strong>E-mailu : <br>
<font color=#999999>Tu zadajte textov� verziu v�ho e-mailu </font>";
$lang_sendmail_htmlversion="<strong>HTML verzia</strong> E-mail : <br> <font
color=#999999>Tu zadajte HTML verziu v�ho e-mailu </font>";
$lang_sendmail_textversion_view="<strong>Textov� verzia </strong>E-mail :
<br> ";
$lang_sendmail_htmlversion_view="<strong>HTML verzia</strong> E-mail : <br>
";
$lang_sendmail_selecttemplate="Najprv zadajte �abl�nu";
$lang_sendmail_usetemplate="Pou�i� �abl�nu";
$lang_sendmail_selecttemplate="Vybra� �abl�nu";
$lang_sendmail_selectdraft="Vyberte koncept";
$lang_sendmail_errortemplate="Chyba : Neschopn� dosta� sa do adres�ra
�abl�n! !!";
$lang_sendmail_errordrafts="Chyba : Neschopn� otvori� adres�r konceptov!
!!";
$lang_sendmail_helptemplate="Pre viac inform�ci� o prid�van� a �prave
�abl�n, �itajte Pomoc. ";
$lang_sendmail_attachment="Attachment";
$lang_sendmail_sendbutton="Posla�";
$lang_sendmail_nextbutton="�alej";
$lang_sendmail_backbutton="Sp�";
$lang_sendmail_stage1="Stupe� 1";
$lang_sendmail_stage2="Stupe� 2";
$lang_sendmail_stage3="Stupe� 3";
$lang_sendmail_to="Posla� e-mail komu ";
$lang_sendmail_to_help="Vyberte komu chcete odosla� e-mail ";
$lang_sendmail_emailID="ID E-mailu";
$lang_sendmail_emailID_help="Vyberte komu chcete odosla� e-mail";
$lang_sendmail_group="Odosla� e-mail skupine";
$lang_sendmail_group_help="Vyberte skupinu, ktorej chcete odosla� e-mail";
$lang_sendmail_single_error="Nezadali ste e-mail";
$lang_sendmail_group_error="Nezadali ste skupinu";
$lang_sendmail_wysiwyg="Pre editovanie v Rich Text Editore";
$lang_sendmail_single="Jednotlivcovi";
$lang_sendmail_group="Skupine";
$lang_sendmail_every="V�etk�m";

/*edit sending */
$lang_send_wait="Pros�m �akajte ... <br><br> Odosiela e-mail";
$lang_send_done="Odosielanie ukon�en� !!<br><br>";
$lang_send_mailing="TOLL Mailing list odosiela e-mail ...";

/*edit wysiwyg */
$lang_editwin_edit="Rich text editor";
$lang_editwin_help="Editovanie HTML v HTML editore";

/*edit maillist members */
$lang_edit_list="Editova� Zoznam adries";
$lang_edit_listex="Tu m��ete prida� , vyh�ad�va� a editova� z�znamy. ";
$lang_edit_new="Zadajte e-mail na pridanie :";
$lang_edit_new_name="Zadajte meno pre e-mail :";
$lang_edit_nomailgroup="Vyberte skupinu";
$lang_edit_expression="Zadajte v�raz pre vyh�ad�vanie v datab�ze";
$lang_edit_correct="Zadajte spr�vny e-mail :";
$lang_edit_correct_name="Zadajte spr�vne meno :";
$lang_edit_delete="Chcete vymaza&raquo; z�znam :";
$lang_edit_jump="---- Prechod do ----";
$lang_edit_jump_group="---- Vyber skupinu ----";
$lang_edit_import="Importova�";
$lang_edit_export="Exportova�";
$lang_edit_add="Prida� upisovate�a";
$lang_edit_search="H�ada�";
$lang_edit_refresh="Obnovi�";
$lang_edit_editdata="Editova� Datab�zu";
$lang_edit_editdataex="Vyberte �kon pomocou linky. ";
$lang_edit_submitted="Podan�";
$lang_edit_ip="Ip Adresa";
$lang_edit_ipedit="Editova�";
$lang_edit_ipdelete="Vymaza�";
$lang_edit_select="<Br><br><center>...Vyberte skupinu na
�pravu...</center><Br><br>";

/*edit maillist members */
$lang_editg_deleted="<br><br><center>Skupina <strong>{group}</strong> bola
�spe�ne vymazan�!!!</center><br><br>";
$lang_editg_added="<br><br><center>Skupina <strong>{group}</strong> bola
�spe�ne pridan�!!!</center><br><br>";
$lang_editg_added_error="<br><br><center>Skupina <strong>{group}</strong> u�
existuje!!!</center><br><br>";
$lang_editg_adit="<br><br><center>Skupina <strong>{group}</strong> bola
editovan�!!!</center><br><br>";
$lang_editg_list="Editova� Skupiny";
$lang_editg_listex="Tu m��ete prida� , vyh�ad�va� a editova� Skupiny ";
$lang_editg_new_name="Zadajte meno novej skupiny na pridanie";
$lang_editg_new="Zadajte ID pre skupinu";
$lang_editg_expression="Zadajte skupinu na vyh�ad�vanie";
$lang_editg_correct="Zadajte spr�vne ID skupiny :";
$lang_editg_correct_name="Pros�m zadajte spr�vne meno skupiny :";
$lang_editg_delete="Chcete vymaza� skupinu :";
$lang_editg_jump="---- Prechod do ----";
$lang_editg_add="Prida� skupinu";
$lang_editg_search="H�ada�";
$lang_editg_refresh="Obnovi�";
$lang_editg_editdata="Editova� Datab�zu";
$lang_editg_editdataex="Vyberte �kon pomocou linky. ";
$lang_editg_ipedit="Editova�";
$lang_editg_ipdelete="Vymaza�";
$lang_editg_subscribers="Upisovatelia";
$lang_editg_name="Meno skupiny ( ID )";

/*edit maillist history */
$lang_edith_title="Hist�ria e-mailov";
$lang_edith_titlex="Zoznam v�etk�ch odoslan�ch e-mailov";
$lang_edith_editdata="Hist�ria odoslan�ch e-mailov";
$lang_edith_editdataex="Vyberte �kon pomocou linky. ";
$lang_edith_date="D�tum";
$lang_edith_edit="Op�tovne posla�";
$lang_edith_to="Poslan� komu";
$lang_edith_delete="Vymaza�";
$lang_edith_delete_history="Chcete vymaza� meno �lohy : ";
$lang_edith_subject="Predmet ";

/*diagnostics */
$lang_diag_simple="Jednoduch� diagnostika";
$lang_diag_simpleex="T�to str�nka je jednoduch� kontrola toho �i s� ur�it�
s�bory zapisovate�n� alebo nie. ";
$lang_diag_status="Stav";
$lang_diag_checking="Kontrola / Chyba";
$lang_diag_globals="Ak je tam chyba, tak potom je s�bor nezapisovate�n�.
Pros�m zme�te povolenia. ";

$lang_diag_temp="Ak je tam chyba tak potom je prechodn� adres�r
nezapisovate�n�. Pros�m zme�te povolenia";

/*import */
$lang_import_adress="Importova� e-mailov� adresy";
$lang_import_adressex="Toto v�m umo�n� importova� e-mailov� adresy z
textov�ho s�boru. ";
$lang_import_import="S�bor na importovanie";
$lang_import_import_help="Vyberte s�bor z ktor�ho chcete importova�
e-mailov� adresy.  E-maily s� v s�bore jednoducho ulo�en� riadok po riadku.
";
$lang_import_next="�alej";
$lang_import_group="Importova� do skupiny";
$lang_import_group_help="Toto je skupina do ktorej bud� importovan�
e-maily";
$lang_import_close="Zavrie�";

/*mainnn inc files */
$lang_email_thanks="�akujeme za va�u registr�ciu";
$lang_emailexist_error="Chyba pri prihlasovan�!!!";
$lang_emailexist_adress="E-mail <b>{email}</b> u� existuje v datab�ze. ";
$lang_emailexist_adress_error="E-mail <b>{email}</b> neexistuje v datab�ze.
";
$lang_emailreg_verify="E-mail bol odoslan� na <b>{email}</b> na overenie
pomocou linky. ";
$lang_emailreg_done="E-mail <b>{email}</b> bol �spe�ne pridan� do datab�zy.
";
$lang_emailunreg_done="E-mail <b>{email}</b> bol �spe�ne odstr�nen� z
datab�zy. ";
$lang_emailremoved="E-mail odstr�nen�";
$lang_removed_adress="E-mail <b>{email}</b> bol �spe�ne odstr�nen� z
datab�zy.";

/*editor */
$lang_htmledit_cancel="Zru�i�";
$lang_htmledit_reset="Resetova�";
$lang_htmledit_save="Ulo�i�";

/*Search */
$lang_search_email="Emails Searchs";
$lang_search_emailex="Here, you can make an avanced search in the Email list";
$lang_search_group="Search in this groups: ";
$lang_search_group_help="The Search will be made in this group";
$lang_search_text="Search Text";
$lang_search="Search";
$lang_search_text_help="In order to look for ex. hotmail.com, try *@hotmail.com, it is used <strong>*</strong> like jokers, if you want to search for ex. webmaster, look for webmaster@*";
$lang_search_allgroups="On all Groups";
$lang_search_text_filter="Total Found";

/* addons*/
$lang_total_group_entries="Total Group Entries:";
$lang_email_name="Email ( Name )";
$lang_send_email="Send a Email";
$lang_show_all_group="Show All Groups";
$lang_see_group="Show Group";

/* charset iso */
$lang_charsetiso[1]="8859-1 - western Europe (Latin-1)";
$lang_charsetiso[2]="8859-2 - Eastern Europe (Latin-2)";
$lang_charsetiso[3]="8859-3 - Southeast of Europe & more (Latin-3)";
$lang_charsetiso[4]="8859-4 - Scandinavian/Balkan (Latin-4)";
$lang_charsetiso[5]="8859-5 - Lat�n/Cyrillic";
$lang_charsetiso[6]="8859-6 - Lat�n/Arab";
$lang_charsetiso[7]="8859-7 - Lat�n/Greek";
$lang_charsetiso[8]="8859-8 - Lat�n/Hebrew";
$lang_charsetiso[9]="8859-9 - Modification Latin-1 Turkish (Latin-5)";
$lang_charsetiso[10]="8859-10 - Lappish/Norway/Eskimo (Latin-6)";
$lang_charsetiso[11]="8859-11 - Thailand";
$lang_charsetiso[12]="8859-12 - Celtic (Latin-7)";
$lang_charsetiso[13]="8859-13 - Baltic (Latin-7)";
$lang_charsetiso[14]="8859-14 - Celtic (Latin-8)";
$lang_charsetiso[15]="8859-15 - Western Europe (Latin-9)";
$lang_charsetiso[16]="8859-16 - South-Eastern European (Latin-10)";
$lang_charsetiso[25]="UTF-8 - Unicode";
$lang_charsetiso[26]="WIN1256 - - Arabic & Persian HTML";//win1256
$lang_charsetiso[27]="CP-866 - Russia";
$lang_charsetiso[28]="TIS-620 - Thailand";
$lang_charsetiso[29]="EUC - Japanese";
$lang_charsetiso[30]="SJIS - Japanese";
$lang_charsetiso[31]="EUC-KR - Korea";
$lang_charsetiso[32]="KOI8-R - Russia";
$lang_charsetiso[33]="GB2312 - Chinese Simplified";
$lang_charsetiso[34]="BIG5 - Chinese Traditional";
$lang_charsetiso[35]="windows-1251 - Bulgaria";

/* new translations*/
$lang_sendmail_everyone="You have chosen to send email to every one in the database";
$lang_main_charsetiso_help="The type of Charset-iso for you email list";
$lang_main_charset="Charset-Iso To Send";
$lang_main_priority_help="The priority of the sending email list";
$lang_priority_text="Priority";
$lang_priority_high="High";
$lang_priority_normal="Normal";
$lang_priority_low="Low";
$lang_sendmail_fromerror="You forgot to fill in Email From";
$lang_sendmail_templateName="Template name";
$lang_sendmail_TemplateAuthor="Template Author";
$lang_sendmail_templateDescription="Description";
$lang_sendmail_templateHomepage="Homepage";
$lang_sendmail_templateNone="None";
?>