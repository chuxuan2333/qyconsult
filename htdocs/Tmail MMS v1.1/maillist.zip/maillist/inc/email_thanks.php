<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="38%"><div align="center"><?php echo $lang_email_thanks; ?></div></td>
  </tr>
  <tr>
    <td><div align="center">&nbsp; </div></td>
  </tr>
  <tr>
    <td><div align="center"><?php echo str_replace("{email}",$email,$lang_emailreg_done); ?></div></td>
  </tr>
  <tr>
    <td><div align="center"></div></td>
  </tr>
</table>