 <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="38%"><div align="center">Removal Error !!!</div></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
  <tr> 
    <td><div align="center"> <?php echo str_replace("{email}",$email,$lang_emailexist_adress_error); ?></div></td>
  </tr>
  <tr> 
    <td>&nbsp;</td>
  </tr>
</table>
