 <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="38%"><div align="center"><?php echo $lang_emailremoved; ?></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><?php echo str_replace("{email}",$email,$lang_removed_adress); ?></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>