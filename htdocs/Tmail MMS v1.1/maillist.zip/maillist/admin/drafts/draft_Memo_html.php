<strong>March 16, 2004</strong><br>
<br>
<br>
<strong>Dear Sir or Madam:</strong><br>
Type your letter here. For more details on modifying this letter template, Please read the help <br>
. <br>
<br>
<strong>Sincerely,</strong><br>
<br>
Your Name
