<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Vote for Tmail </title>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<LINK title=style-sheet href="admin/css/admin.css" type=text/css rel=stylesheet>
<link href="css/admin.css" rel="stylesheet" type="text/css">
</head>

<body background="admin/images/interface/backgd.gif" >
<table width="100%" height="100%" border="0" align="center" cellpadding="10" cellspacing="0">
   <tr>
    <td bgcolor="#FFFFFF"> <table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
        <tr>
          <td width="100%"><span class="h3">����ϵͳͶƱ</span><br>
            <span class="f8">�������ô�ϵͳ��ʱ��ֵ,�������Ͷ��һƱ��.</span></td>
        </tr>
        <tr>
          <td colspan="2" valign="top"><FORM
                                action=http://www.cms8.com/mail/vote/vote.asp
                                method=post>
              <table width="85%" border="0" align="center" cellpadding="0" cellspacing="0" background="admin/images/interface/spacer_horizontal.gif">
                <tr>
                  <td ><img src="admin/images/spacer.gif" width="1" height="1"></td>
                </tr>
              </table>

            <INPUT type=hidden value=29077
                                name=ID>
              <br>
              <br>
              <TABLE border=0 align="center" cellPadding=1 cellSpacing=0
                                bgColor=#CCCCCC>
                <TBODY>
                  <TR>
                    <TD> <TABLE cellSpacing=0 cellPadding=4
                                bgColor=#ffffff border=0>
                        <TBODY>
                          <TR>
                            <TD><INPUT type=radio value=5 name=rate></TD>
                            <TD>׿Խ!</TD>
                          </TR>
                          <TR>
                            <TD><INPUT type=radio value=4 name=rate></TD>
                            <TD>�ü���!</TD>
                          </TR>
                          <TR>
                            <TD><INPUT type=radio value=3 name=rate></TD>
                            <TD>�ܺ�</TD>
                          </TR>
                          <TR>
                            <TD><INPUT type=radio value=2 name=rate></TD>
                            <TD>һ��</TD>
                          </TR>
                          <TR>
                            <TD><INPUT type=radio value=1 name=rate></TD>
                            <TD>����</TD>
                          </TR>
                          <TR>
                            <TD align=middle colSpan=2><INPUT name="submit" type=submit class="textbox" value="ͶƱ!"></TD>
                          </TR>
                        </TBODY>
                      </TABLE></TD>
                  </TR>
                </TBODY>
              </TABLE>
            </FORM></td>
        </tr>
      </table></td>
  </tr>
</table>
</body>
</html>