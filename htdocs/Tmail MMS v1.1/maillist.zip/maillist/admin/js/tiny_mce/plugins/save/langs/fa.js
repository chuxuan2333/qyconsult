﻿// IR lang variables
// Persian (Farsi) language pack (for IRAN)
// By: Morteza Zafari
// Lost@LostLord.com
// http://www.LostLord.com

tinyMCELang['lang_dir'] = 'rtl';
tinyMCELang['lang_save_desc'] = 'ضبط'; 