// DE lang variables

tinyMCELang['lang_insert_flash']      = 'Flash Movie einf&uuml;gen / bearbeiten';
tinyMCELang['lang_insert_flash_file'] = 'Flash-Datei';
tinyMCELang['lang_insert_flash_size'] = 'Gr&ouml;&szlig;e';
tinyMCELang['lang_insert_flash_list'] = 'Flash Dateien';
tinyMCELang['lang_flash_props'] = 'Flash properties';
