// CA_FR lang variables

tinyMCELang['lang_save_desc'] = 'Enregistrer'; 