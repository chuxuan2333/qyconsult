﻿// PL lang variables


tinyMCELang['lang_preview_desc'] = 'Podgląd';