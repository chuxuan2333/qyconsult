// Simplified Chinese lang variables contributed by cube316 (cube316@etang.com)

tinyMCELang['lang_print_desc'] = '��ӡ';
