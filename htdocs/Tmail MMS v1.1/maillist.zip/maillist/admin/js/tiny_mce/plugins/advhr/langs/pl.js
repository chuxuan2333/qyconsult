﻿// PL lang variables

tinyMCELang['lang_insert_advhr_desc']    = 'Wstaw/Edytuj poziomą linię'
tinyMCELang['lang_insert_advhr_width']   = 'Szerokość';
tinyMCELang['lang_insert_advhr_size']    = 'Wysokość';
tinyMCELang['lang_insert_advhr_noshade'] = 'Brak cienia';