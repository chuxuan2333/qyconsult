// CAN_FR lang variables

tinyMCELang['lang_insert_emotions_title'] = 'Ins�rer un �moticon';
tinyMCELang['lang_emotions_desc'] = '�moticons';

