﻿// PL lang variables

tinyMCELang['lang_insert_flash']      = 'Wstaw/Edytuj animację Flash';
tinyMCELang['lang_insert_flash_file'] = 'Plik Flash (.swf)';
tinyMCELang['lang_insert_flash_size'] = 'Rozmiar';
tinyMCELang['lang_insert_flash_list'] = 'Pliki Flash';
tinyMCELang['lang_flash_props'] = 'Właściwości animacji Flash';