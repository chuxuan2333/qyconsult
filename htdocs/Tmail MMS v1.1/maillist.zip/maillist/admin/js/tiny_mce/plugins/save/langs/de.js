// DE lang variables 

tinyMCELang['lang_save_desc'] = 'Speichern'; 