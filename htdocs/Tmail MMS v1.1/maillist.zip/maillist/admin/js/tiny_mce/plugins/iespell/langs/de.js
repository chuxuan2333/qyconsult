// DE lang variables by Tobias Heer

tinyMCELang['lang_iespell_desc'] = 'Rechtschreibpr&uuml;fung';
tinyMCELang['lang_iespell_download'] = "ieSpell nicht gefunden. Klicken Sie OK um auf die Download Seite zu gelangen."
