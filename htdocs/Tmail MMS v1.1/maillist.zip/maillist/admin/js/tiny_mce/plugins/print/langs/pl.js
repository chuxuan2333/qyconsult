﻿// PL lang variables


tinyMCELang['lang_print_desc'] = 'Drukuj';