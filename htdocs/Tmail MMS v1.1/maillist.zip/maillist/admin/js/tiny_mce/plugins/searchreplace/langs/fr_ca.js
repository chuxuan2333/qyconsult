// CA_FR lang variables

tinyMCELang['lang_searchreplace_search_desc'] = 'Chercher';
tinyMCELang['lang_searchreplace_searchnext_desc'] = 'Chercher suivant';
tinyMCELang['lang_searchreplace_replace_desc'] = 'Chercher/Remplacer';
tinyMCELang['lang_searchreplace_notfound'] = 'La recherche est termin�e.  Aucune occurence trouv�e.';
tinyMCELang['lang_searchreplace_search_title'] = 'Chercher';
tinyMCELang['lang_searchreplace_replace_title'] = 'Chercher/Remplacer';
tinyMCELang['lang_searchreplace_allreplaced'] = 'Toutes les occurences ont �t� remplac�es.';
tinyMCELang['lang_searchreplace_findwhat'] = 'Chercher quoi';
tinyMCELang['lang_searchreplace_replacewith'] = 'Remplacer par';
tinyMCELang['lang_searchreplace_direction'] = 'Direction';
tinyMCELang['lang_searchreplace_up'] = 'Monter';
tinyMCELang['lang_searchreplace_down'] = 'Descendre';
tinyMCELang['lang_searchreplace_case'] = 'Sensible � la case';
tinyMCELang['lang_searchreplace_findnext'] = 'Chercher&nbsp;suivant';
tinyMCELang['lang_searchreplace_replace'] = 'Remplacer';
tinyMCELang['lang_searchreplace_replaceall'] = 'Remplacer&nbsp;tous';
tinyMCELang['lang_searchreplace_cancel'] = 'Annuler';

