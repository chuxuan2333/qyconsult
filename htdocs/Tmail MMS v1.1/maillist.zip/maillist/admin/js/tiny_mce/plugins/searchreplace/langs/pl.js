﻿// PL lang variables


tinyMCELang['lang_searchreplace_search_desc'] = 'Znajdź';
tinyMCELang['lang_searchreplace_searchnext_desc'] = 'Znajdź ponownie';
tinyMCELang['lang_searchreplace_replace_desc'] = 'Znajdź/Zastąp';
tinyMCELang['lang_searchreplace_notfound'] = 'Ukończono wyszukiwanie. Poszukiwana fraza nie została odnaleziona.';
tinyMCELang['lang_searchreplace_search_title'] = 'Znajdź';
tinyMCELang['lang_searchreplace_replace_title'] = 'Znajdź/Zastąp';
tinyMCELang['lang_searchreplace_allreplaced'] = 'Wszystkie wystąpienia poszukiwanej frazy zostały zastąpione. ';
tinyMCELang['lang_searchreplace_findwhat'] = 'Znajdź';
tinyMCELang['lang_searchreplace_replacewith'] = 'Zastąp';
tinyMCELang['lang_searchreplace_direction'] = 'Kierunek';
tinyMCELang['lang_searchreplace_up'] = 'Do góry';
tinyMCELang['lang_searchreplace_down'] = 'Do dołu';
tinyMCELang['lang_searchreplace_case'] = 'Wielkość liter';
tinyMCELang['lang_searchreplace_findnext'] = 'Znajdź&nbsp;następny';
tinyMCELang['lang_searchreplace_replace'] = 'Zastąp';
tinyMCELang['lang_searchreplace_replaceall'] = 'Zastąp&nbsp;wszystkie';
tinyMCELang['lang_searchreplace_cancel'] = 'Wyjdź';
