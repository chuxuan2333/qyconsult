// CA_FR lang variables

tinyMCELang['lang_insert_image_alt2'] = 'Titre de l\'image';
tinyMCELang['lang_insert_image_onmousemove'] = 'Image alternative';
tinyMCELang['lang_insert_image_mouseover'] = 'pour le �mouse over�';
tinyMCELang['lang_insert_image_mouseout'] = 'pour le �mouse out�';
