﻿// IR lang variables
// Persian (Farsi) language pack (for IRAN)
// By: Morteza Zafari
// Lost@LostLord.com
// http://www.LostLord.com

tinyMCELang['lang_dir'] = 'rtl';
tinyMCELang['lang_insertdate_desc'] = 'افزودن تاریخ';
tinyMCELang['lang_inserttime_desc'] = 'افزودن زمان';
