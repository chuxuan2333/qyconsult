<?php if(!isset($_SESSION['admin'])) {echo ' Hacking Attempted '; return; } ?>
<!------- Start of HTML Code ------->

 <table width="770" border="0" align="center" cellpadding="0" cellspacing="0" background="admin/images/interface/bgmaintable.gif">
  <tr>
    <td width="20">&nbsp;</td>
     <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
        <tr>
          <td class="h3"> <table width="100%" border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td height="25" class="h3">�������� </td>
                <td height="25" valign="bottom"><div align="right" class="f8">һЩ���ڴ����뿪���ߵ���Ϣ.</div></td>
              </tr>
            </table></td>
        </tr>
         <tr>
          <td></td>
        </tr>
         <tr bgcolor="#0066CC">
          <td colspan="2"><img src="images/interface/spacer.gif" width="1" height="1"></td>
        </tr>
       </table>
      <br>
      <br>
      <div align="center">
        <table width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td bgcolor="#FFFFFF"><div align="right">
                 <table width="95%" border="0" align="center" cellpadding="0" cellspacing="1">
                  <tr>
                    <td> <br>
                      <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" background="admin/images/interface/spacer_horizontal.gif">
                        <tr>
                          <td width="612"><img src="admin/images/spacer.gif" width="1" height="1"></td>
                        </tr>
                      </table>
                      <br>
                      <table width="100%" height="310" border="0" align="center" cellpadding="0" cellspacing="10">
                         <tr>
                          <td width="37%">�������� :</td>
                          <td width="63%"><strong> Tmail MMS </strong></td>
                        </tr>
                         <tr>
                          <td>����汾 :<span class="f8"></span></td>
                          <td>Version 1.0</td>
                        </tr>
                         <tr>
                          <td valign="top">�����Ŷ� : </td>
                          <td><p><a href="mailto:admin@ngcoders.com" ><strong>Vikas Patial</strong></a><strong> </strong>[ <a href="http://www.ngcoders.com" target="_blank" >www.ngcoders.com</a> ] <br>
                          <br>
                              <a href="mailto:webmaster@mail.cms8.com" ><strong>Toll</strong></a> [ <a href="http://www.cms8.com" target="_blank" >www.cms8.com </a> ] <br>
                            <br>
                              <a href="mailto:info@cfconsultancy.com" ><strong>Ceasar Feijen</strong></a> [ <a href="http://www.cfconsultancy.com" target="_blank" >www.cfconsultancy.nl </a> ] <br>
                              </p></td>
                        </tr>
                        <tr>
                           <td>BUG���� <span class="f8"></span></td>
                           <td><a href="mailto:moises@hgmnetwork.com" ><strong>Moises Hdez</strong></a> [ <a href="http://www.hgmnetwork.com" target="_blank" >www.hgmnetwork.com</a>]</td>
                        </tr>
                         <tr>
                           <td>ƽ������<span class="f8"></span></td>
                           <td><a href="mailto:info@pixelate.nl" ><strong>Roland Poot </strong></a> [ <a href="http://www.pixelate.nl" target="_blank" >www.pixelate.nl </a> ]</td>
                         </tr>
                         <tr>
                          <td>�й��ٷ� :<span class="f8"></span></td>
                          <td><a href="http://www.cms8.com" >http://www.cms8.com/</a></td>
                        </tr>
                         <tr>
                          <td>����֧�� :</td>
                          <td><a href="http://www.cms8.com/bbs/index.asp"  >http://www.cms8.com/bbs</a></td>
                        </tr>
                         <tr>
                          <td valign="top">��ȨЭ�� : </td>
                          <td> ������������ѿ�Դ�ṩ,���Ƕ���������,�����ṩ���õķ���.
<BR><BR>
                           </td>
                        </tr>
                    </table></td>
                   </tr>
                </table>
                 <p> <table border=1 align="center" bordercolor="#CCCCCC"><tr><td><div align="center">������������(Ԥ��) </div></td>
                        </tr>
                    </table>
                 </p>
            </div></td>
           </tr>
        </table>
       </div></td>
     <td width="20">&nbsp;</td>
   </tr>
</table>
