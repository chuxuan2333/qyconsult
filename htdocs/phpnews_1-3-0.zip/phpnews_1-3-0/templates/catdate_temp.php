<?php
print<<<EOT
<a href="$url?cat=$catid&amp;month=$cat[month]&amp;year=$year">$month $year</a> ($numPosts)<br />
EOT;
?>
