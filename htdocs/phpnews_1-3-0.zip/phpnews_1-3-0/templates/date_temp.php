<?php
print<<<EOT
<a href="$url?month=$arc[month]&amp;year=$year">$month $year</a> ($numPosts)<br />
EOT;
?>
