<?php
print<<<EOT
<a href="$url?cat=$catid">$category</a><br />
EOT;
?>
