<?php
print<<<EOT
<p style="border-top:#000000 solid 1px; border-bottom:#000000 solid 1px;">
   Posted By $name $link on $time<br />
   $message
</p>\n
EOT;
?>
