<?php
print<<<EOT
<a href="$url?action=fullnews&amp;showcomments=1&amp;id=$id">$subject</a> by $username on $time<br />
EOT;
?>
