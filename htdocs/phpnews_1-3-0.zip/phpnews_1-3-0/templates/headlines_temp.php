<?php
print<<<EOT
<a href="{$Settings['siteurl']}#ni$mid">$subject</a>, by $username posted on $time<br />
EOT;
?>
